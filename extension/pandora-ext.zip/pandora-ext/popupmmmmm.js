var amazonSearchTemplate = "http://www.amazon.com/mn/search/?_encoding=UTF8&x=0&tag=universa04-20&linkCode=ur2&y=0&camp=1789&creative=390957&field-keywords=[KEYWORD]&url=search-alias%3Daps";

function launch(url) {
    window.open(url,'_blank');
}
function sendReq(action) {
    chrome.extension.sendRequest({action: action}, function(response) {});
}

var tabId;
chrome.extension.sendRequest({action: 'getTabId'}, function(response) {
    tabId = response.tabId;
});

document.addEventListener('keydown', function(e) {
    if (e.keyCode == 32) {
        sendReq('pause');
    } else if (e.keyCode == 37) {
        sendReq('rewind');
    } else if (e.keyCode == 39) {
        sendReq('next');
    }
});

function updateUI(uiState) {
    document.getElementById('songName').innerHTML = uiState.title;
    document.getElementById('artistName').innerHTML = uiState.artist;
    document.getElementById('albumArt').src = uiState.albumArt;
    if (uiState.playing == true){
    	document.body.classList.add('playing');
    }
    if (uiState.playing == false) {
    	document.body.classList.remove('playing');
    }
    if (uiState.thumbsUp == true) {
      thumbup.classList.add('toggled');
    } 
    if (uiState.thumbsDown == true) {
      thumbdown.classList.add('toggled');
    }
    if (uiState.thumbsDown == false) {
      thumbdown.classList.remove('toggled');
    }	
    if (uiState.thumbsUp == false) {
      thumbup.classList.remove('toggled');
    }
    if (uiState.favorite) {
      favorite.classList.add('toggled');
    } else {
      favorite.classList.remove('toggled');
    }
    var serviceName = document.getElementById('serviceName');
    if (uiState.service) {
      serviceName.innerText = "via " + uiState.service;
      serviceName.style.display = "";
    } else {
      serviceName.style.display = "none";
    }
    var supports = uiState.supports;
    playPause.style.display = supports.playpause ? 'block' : 'none';
    ffwd.style.display = supports.next ? 'block' : 'none';	
    rewind.style.display = supports.previous ? 'block' : 'none';
    thumbup.style.display = supports.thumbsup ? 'block' : 'none';
    thumbdown.style.display = supports.thumbsdown ? 'block' : 'none';	
    favorite.style.display = supports.favorite ? 'block' : 'none';		
    controls.style.display = ''; // Dont set this to block, it needs to be webkit-box as defined in the css.
    launchicon.style.display = 'none';
    songDetails.style.display = '';
    buylinkHolder.style.display = '';
    
    var amazonURL = amazonSearchTemplate.replace("[KEYWORD]", uiState.artist + " - " + uiState.title);
    document.getElementById('amazonLink').href = amazonURL;
}

chrome.extension.onRequest.addListener(
	function (request, sender, sendResponse){
	    if (request.action == 'requestFocus') {
	        tabId = sender.tab.id;
	    }
	    if (sender.tab && sender.tab.id == tabId) {
	        updateUI(request);
        }
	}
);
function debug() {
  controls.style.display = '';
  launchicon.style.display = 'none';
  songDetails.style.display = '';
  buylinkHolder.style.display = '';
}

$ = function(id) {
  return document.getElementById(id);
}

function actionClick(divId, action) {
  document.getElementById(divId).addEventListener('click', function() {
    sendReq(action)
  });
}

function load() {
  actionClick('thumbdown', 'thumbdown');
  actionClick('thumbup', 'thumbup');
  actionClick('favorite', 'favorite');
  actionClick('rewind', 'rewind');
  actionClick('playPause', 'pause');
  actionClick('ffwd', 'next');
  actionClick('songDetails', 'focus')
}
document.addEventListener("DOMContentLoaded", load, false);

//setTimeout(debug, 50);
sendReq('getState');

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-35127344-1']);
_gaq.push(['_trackPageview']);

(function() {
  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();