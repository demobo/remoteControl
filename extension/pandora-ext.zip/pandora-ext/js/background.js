function onMessage(message, sender, sendResponse) {
	if (message == 'pingback') {
		chrome.pageAction.show(sender.tab.id);
//		chrome.browserAction.enable(sender.tab.id);
//		chrome.browserAction.setPopup({tabId: sender.tab.id, popup: ""});
	}
	sendResponse({});
};
chrome.extension.onMessage.addListener(onMessage);

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
	chrome.tabs.sendMessage(tab.id,'ping');
//	chrome.browserAction.disable(tab.id);
});
chrome.browserAction.onClicked.addListener(function(tab){
	chrome.tabs.sendMessage(tab.id,'toggleDemobo');
});
chrome.pageAction.onClicked.addListener(function(tab){
	chrome.tabs.sendMessage(tab.id,'toggleDemobo');
});